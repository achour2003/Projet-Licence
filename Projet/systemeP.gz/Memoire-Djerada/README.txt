Instructions pour compiler et exécuter le projet

1. Décompressez l'archive :
   tar -xzvf Memoire-Achour.tar.gz

2. Allez dans le répertoire du projet :
   cd Memoire-Achour

3. Compilez les fichiers :
   make

4. Exécutez le serveur :
   ./serveur

5. Exécutez le client dans un autre terminal :
   ./client

Note importante :
Si la liaison à la socket ne se fait pas (le message "la connexion au serveur a échoué" apparaît), fermez le terminal et recommencez les étapes 4 et 5. Assurez-vous également que le serveur est en cours d'exécution avant de démarrer le client.

Si vous rencontrez des problèmes supplémentaires, veuillez vérifier les points suivants :
- Assurez-vous que toutes les dépendances et bibliothèques nécessaires sont installées.
- Vérifiez les permissions des fichiers avec la commande `ls -la`.
- Pour toute autre question, référez-vous au fichier source et aux commentaires dans le code.

Bibliothèques nécessaires :
- pthread
- stdio
- stdlib
- string
- unistd
- arpa/inet
- netinet/in
- netdb
- signal

