<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="murIndistructible" tilewidth="80" tileheight="80" tilecount="1" columns="1">
 <image source="murIndistructible.PNG" width="80" height="80"/>
</tileset>
