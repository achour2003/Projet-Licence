<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="boule-removebg-preview(1)" tilewidth="80" tileheight="80" tilecount="1" columns="1">
 <image source="boule-removebg-preview(1).png" width="91" height="83"/>
</tileset>
